package com.example.mislugares.presentacion

import android.app.Activity
import android.os.Bundle
import com.example.mislugares.R

class AcercaDeActivity : Activity() {
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.acercade)
    }
}
